// Don't touch this file!

void flood(char** map, int size, int steps);
