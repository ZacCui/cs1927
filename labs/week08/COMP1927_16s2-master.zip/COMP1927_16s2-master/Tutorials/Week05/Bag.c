//Our Bag ADT Impl

#include "Bag.h"
#include <stdio.h>

struct BagRep {

};

void dropBag(Bag bag) {
  (void)bag;
}

Bag BagCopy(Bag bag) {
  (void)bag;
}

void BagInsert(Bag bag, int v) {
  (void)bag;
  (void)v;
}

void BagDelete(Bag bag,int v) {
  (void)bag;
  (void)v;
}

int BagMember(Bag bag, int v) {
  (void)bag;
  (void)v;
}

Bag BagUnion(Bag bag1,Bag bag2) {
  (void)bag1;
  (void)bag2;
}

Bag BagIntersect(Bag bag1, Bag bag2) {
  (void)bag1;
  (void)bag2;
}

int BagNumElems(Bag bag) {
  (void)bag;
}

int BagNumUniq(Bag bag) {
  (void)bag;
}

void showBag(Bag bag) {
  (void)bag;
}

void readBag(FILE* file, Bag bag) {
  (void)file;
  (void)bag;
}
